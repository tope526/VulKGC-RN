from email import header
from unicodedata import name
import torch

from models import SpKBGATModified, SpKBGATConvOnly
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from copy import deepcopy

from preprocess import read_entity_from_id, read_relation_from_id, init_embeddings, build_data
from create_batch import Corpus
from utils import save_model

import random
import argparse
import os
import sys
import logging
import time
import pickle
import pandas as pd

#除风复现对比论文使用其对比论文的参数，其它参数一概使用模型默认的

def parse_args():
    args = argparse.ArgumentParser()
    #参数设置
    args.add_argument("-data", "--data",
                      default="../VulKGC-RN/data/VulKG/")#数据集路径
    args.add_argument("-e_g", "--epochs_gat", type=int,
                      default=3600, help="Number of epochs")#默认3600，用于控制邻域特征生成模型GAT的训练学习次数
    args.add_argument("-e_gt", "--epochs_gat_train", type=int,
                      default=3600, help="Number of epochs")#默认3600，表示某个训练好的邻域特征GAT模型的次数，用于获取训练好的GAT模型
    args.add_argument("-e_c", "--epochs_conv", type=int,
                      default=200, help="Number of epochs")#默认200
    args.add_argument("-w_gat", "--weight_decay_gat", type=float,
                      default=5e-6, help="L2 reglarization for gat")
    args.add_argument("-w_conv", "--weight_decay_conv", type=float,
                      default=1e-5, help="L2 reglarization for conv")
    args.add_argument("-pre_emb", "--pretrained_emb", type=bool,
                      default=True, help="Use pretrained embeddings")#由于有预训练嵌入文件TranE，所以default=Ture
    args.add_argument("-emb_size", "--embedding_size", type=int,
                      default=484, help="Size of embeddings (if pretrained not used)")#初始嵌入向量484
    args.add_argument("-l", "--lr", type=float, default=1e-3)#就是0.001，太慢了 
    args.add_argument("-g2hop", "--get_2hop", type=bool, default=True)#写入，第一次设为True，正向邻居范围
    args.add_argument("-g2hop_r", "--get_2hop_re", type=bool, default=False)#写入，第一次设为True，逆向邻居范围,与get_2hop不能同时为True
    args.add_argument("-u2hop", "--use_2hop", type=bool, default=False)#读出 
    args.add_argument("-p2hop", "--partial_2hop", type=bool, default=False)
    args.add_argument("-outfolder", "--output_folder",
                      default="../VulKGC-RN/results/transe_sbert/")#训练好的模型保存地址

    # GAT
    args.add_argument("-b_gat", "--batch_size_gat", type=int,
                      default=8923, help="Batch size for GAT")#默认8923
    args.add_argument("-neg_s_gat", "--valid_invalid_ratio_gat", type=int,
                      default=2, help="Ratio of valid to invalid triples for GAT training")
    args.add_argument("-drop_GAT", "--drop_GAT", type=float,
                      default=0.3, help="Dropout probability for SpGAT layer")
    args.add_argument("-alpha", "--alpha", type=float,
                      default=0.2, help="LeakyRelu alphs for SpGAT layer")
    args.add_argument("-out_dim", "--entity_out_dim", type=int, nargs='+',
                      default=[100, 200], help="Entity output embedding dimensions")
    args.add_argument("-h_gat", "--nheads_GAT", type=int, nargs='+',
                      default=[2, 2], help="Multihead attention SpGAT")
    args.add_argument("-margin", "--margin", type=float,
                      default=5, help="Margin used in hinge loss")

    #convKB
    args.add_argument("-b_conv", "--batch_size_conv", type=int,
                      default=128, help="Batch size for conv")
    args.add_argument("-alpha_conv", "--alpha_conv", type=float,
                      default=0.2, help="LeakyRelu alphas for conv layer")
    args.add_argument("-neg_s_conv", "--valid_invalid_ratio_conv", type=int, default=40,
                      help="Ratio of valid to invalid triples for convolution training")
    args.add_argument("-o", "--out_channels", type=int, default=500,
                      help="Number of output channels in conv layer")
    args.add_argument("-drop_conv", "--drop_conv", type=float,
                      default=0.3, help="Dropout probability for convolution layer")#m默认0.3

    args = args.parse_args()
    return args


args = parse_args()#初始化参数


def load_data(args):
    train_data, validation_data, test_data, entity2id, relation2id, headTailSelector, unique_entities_train = build_data(
        args.data, is_unweigted=False, directed=True)#有向图，train_data中（train_triples，train_adjacency_mat）即（（头，关系，尾），（尾，头，权重））

    if args.pretrained_emb:#如果有预训练嵌入，就通过这段代码读取
        entity_embeddings, relation_embeddings = init_embeddings(os.path.join(args.data, 'entity2vec.txt'),
                                                                 os.path.join(args.data, 'relation2vec.txt'))
        print("Initialised relations and entities from my")

    else:
        entity_embeddings = np.random.randn(
            len(entity2id), args.embedding_size)
        relation_embeddings = np.random.randn(
            len(relation2id), args.embedding_size)
        print("Initialised relations and entities randomly")

    corpus = Corpus(args, train_data, validation_data, test_data, entity2id, relation2id, headTailSelector,
                    args.batch_size_gat, args.valid_invalid_ratio_gat, unique_entities_train, args.get_2hop,args.get_2hop_re)

    return corpus, torch.FloatTensor(entity_embeddings), torch.FloatTensor(relation_embeddings)


Corpus_, entity_embeddings, relation_embeddings = load_data(args)


if(args.get_2hop):
    file = args.data + "/2hop.pickle"
    with open(file, 'wb') as handle:
        pickle.dump(Corpus_.node_neighbors_2hop, handle,
                    protocol=pickle.HIGHEST_PROTOCOL)

if(args.get_2hop_re):
    file = args.data + "/2hop_re.pickle"#注意捕获逆向特征时
    with open(file, 'wb') as handle:
        pickle.dump(Corpus_.node_neighbors_2hop, handle,
                    protocol=pickle.HIGHEST_PROTOCOL)


if(args.get_2hop and args.use_2hop):
    print("Opening node_neighbors pickle object")
    file = args.data + "/2hop.pickle"
    with open(file, 'rb') as handle:
        node_neighbors_2hop = pickle.load(handle)

if(args.get_2hop_re and args.use_2hop):
    print("Opening node_neighbors pickle object")
    file = args.data + "/2hop_re.pickle"
    with open(file, 'rb') as handle:
        node_neighbors_2hop = pickle.load(handle)

print("Initial entity dimensions {} , relation dimensions {}".format(
    entity_embeddings.size(), relation_embeddings.size()))


CUDA = torch.cuda.is_available()

def batch_gat_loss(gat_loss_func, train_indices, entity_embed, relation_embed):
    len_pos_triples = int(
        train_indices.shape[0] / (int(args.valid_invalid_ratio_gat) + 1))

    pos_triples = train_indices[:len_pos_triples]
    neg_triples = train_indices[len_pos_triples:]

    pos_triples = pos_triples.repeat(int(args.valid_invalid_ratio_gat), 1)

    source_embeds = entity_embed[pos_triples[:, 0]]
    relation_embeds = relation_embed[pos_triples[:, 1]]
    tail_embeds = entity_embed[pos_triples[:, 2]]

    x = source_embeds + relation_embeds - tail_embeds
    pos_norm = torch.norm(x, p=1, dim=1)

    source_embeds = entity_embed[neg_triples[:, 0]]
    relation_embeds = relation_embed[neg_triples[:, 1]]
    tail_embeds = entity_embed[neg_triples[:, 2]]

    x = source_embeds + relation_embeds - tail_embeds
    neg_norm = torch.norm(x, p=1, dim=1)

    y = -torch.ones(int(args.valid_invalid_ratio_gat) * len_pos_triples).cuda()

    loss = gat_loss_func(pos_norm, neg_norm, y)
    return loss


def train_gat(args):

    print("Defining model")

    print(
        "\nModel type -> GAT layer with {} heads used , Initital Embeddings training".format(args.nheads_GAT[0]))
    model_gat = SpKBGATModified(entity_embeddings, relation_embeddings, args.entity_out_dim, args.entity_out_dim,
                                args.drop_GAT, args.alpha, args.nheads_GAT)

    if CUDA:
        model_gat.cuda()

    optimizer = torch.optim.Adam(
        model_gat.parameters(), lr=args.lr, weight_decay=args.weight_decay_gat)

    scheduler = torch.optim.lr_scheduler.StepLR(
        optimizer, step_size=500, gamma=0.5, last_epoch=-1)

    gat_loss_func = nn.MarginRankingLoss(margin=args.margin)

    current_batch_2hop_indices = torch.tensor([])
    if(args.use_2hop):
        current_batch_2hop_indices = Corpus_.get_batch_nhop_neighbors_all(args,Corpus_.unique_entities_train, node_neighbors_2hop)

    if CUDA:
        current_batch_2hop_indices = Variable(
            torch.LongTensor(current_batch_2hop_indices)).cuda()
    else:
        current_batch_2hop_indices = Variable(
            torch.LongTensor(current_batch_2hop_indices))

    epoch_losses = []   # losses of all epochs
    print("Number of epochs {}".format(args.epochs_gat))

    for epoch in range(args.epochs_gat):#训练邻域特征提取器
        print("\nepoch-> ", epoch)
        random.shuffle(Corpus_.train_triples)
        Corpus_.train_indices = np.array(
            list(Corpus_.train_triples)).astype(np.int32)

        model_gat.train()  # getting in training mode
        start_time = time.time()
        epoch_loss = []

        if len(Corpus_.train_indices) % args.batch_size_gat == 0:
            num_iters_per_epoch = len(
                Corpus_.train_indices) // args.batch_size_gat
        else:
            num_iters_per_epoch = (
                len(Corpus_.train_indices) // args.batch_size_gat) + 1

        for iters in range(num_iters_per_epoch):
            start_time_iter = time.time()
            train_indices, train_values = Corpus_.get_iteration_batch(iters)

            if CUDA:
                train_indices = Variable(
                    torch.LongTensor(train_indices)).cuda()
                train_values = Variable(torch.FloatTensor(train_values)).cuda()

            else:
                train_indices = Variable(torch.LongTensor(train_indices))
                train_values = Variable(torch.FloatTensor(train_values))

            # forward pass
            entity_embed, relation_embed = model_gat(
                Corpus_, Corpus_.train_adj_matrix, train_indices, current_batch_2hop_indices)

            optimizer.zero_grad()

            loss = batch_gat_loss(
                gat_loss_func, train_indices, entity_embed, relation_embed)

            loss.backward()
            optimizer.step()

            epoch_loss.append(loss.data.item())

            end_time_iter = time.time()

            print("Iteration-> {0}  , Iteration_time-> {1:.4f} , Iteration_loss {2:.4f}".format(
                iters, end_time_iter - start_time_iter, loss.data.item()))

        scheduler.step()
        print("Epoch {} , average loss {} , epoch_time {}".format(
            epoch, sum(epoch_loss) / len(epoch_loss), time.time() - start_time))
        epoch_losses.append(sum(epoch_loss) / len(epoch_loss))
        
        if args.get_2hop:#如果当前训练的GAT是捕获正向邻域特征的，保存为"trained_{}.pth"
            save_model(model_gat, args.data, epoch,args.output_folder,mre=False)
        if args.get_2hop_re:#如果当前训练的GAT是捕获逆向邻域特征的，保存为"trained_re_{}.pth"
            save_model(model_gat, args.data, epoch,args.output_folder,mre=True)

def train_conv(args): 

    print("Defining model")
    model_gat = SpKBGATModified(entity_embeddings, relation_embeddings, args.entity_out_dim, args.entity_out_dim,
                                args.drop_GAT, args.alpha, args.nheads_GAT)
    model_gat_re = SpKBGATModified(entity_embeddings, relation_embeddings, args.entity_out_dim, args.entity_out_dim,
                                args.drop_GAT, args.alpha, args.nheads_GAT)

    print("Only Conv model trained")
    model_conv = SpKBGATConvOnly(entity_embeddings, relation_embeddings, args.entity_out_dim, args.entity_out_dim,
                                 args.drop_GAT, args.drop_conv, args.alpha, args.alpha_conv,
                                 args.nheads_GAT, args.out_channels)

    if CUDA:
        model_conv.cuda()
        model_gat.cuda()
        model_gat_re.cuda()

    
    #第三次执行时，该注释取消
    model_gat_re.load_state_dict(torch.load(
        '{}/trained_re_{}.pth'.format(args.output_folder, args.epochs_gat_train-1)), strict=False)#加载训练到某epoch次的GAT模型,以获得逆向特征
    model_gat.load_state_dict(torch.load(
        '{}/trained_{}.pth'.format(args.output_folder, args.epochs_gat_train-1)), strict=False)#加载训练到某epoch次的GAT模型,以获得正向特征
    
    
    
    model_conv.final_entity_embeddings = model_gat.final_entity_embeddings
    model_conv.final_relation_embeddings = model_gat.final_relation_embeddings
    
    e_m_1=torch.clone(model_gat.final_entity_embeddings)        #torch.Size([7199, 484])#实体的正向特征向量
    e_m_re=torch.clone(model_gat_re.final_entity_embeddings)  #torch.Size([7199, 484]) #实体的逆向特征向量
    print(type(e_m_1),e_m_1.shape)
    print(type(e_m_re),e_m_re.shape)

    r_m_1=torch.clone(model_gat.final_relation_embeddings)      #torch.Size([15, 484])#关系的正向特征向量
    r_m_re=torch.clone(model_gat_re.final_relation_embeddings) #torch.Size([15, 484]) #关系的逆向特征向量
    print(type(r_m_1),r_m_1.shape)
    print(type(r_m_re),r_m_re.shape)
    
    #e_m = e_m_1+e_m_re  #融合嵌入
    #r_m = r_m_1+r_m_re
    e_m = (e_m_1+e_m_re)/2  #融合嵌入，有的版本除2无法执行，可以采用不除2的情况
    r_m = (r_m_1+r_m_re)/2
    print(type(e_m),e_m.shape) 
    print(type(r_m),r_m.shape)#torch.Size([15, 484]) 

    model_conv.final_entity_embeddings = nn.Parameter(e_m)
    model_conv.final_relation_embeddings =nn.Parameter(r_m) 


    Corpus_.batch_size = args.batch_size_conv
    Corpus_.invalid_valid_ratio = int(args.valid_invalid_ratio_conv)

    optimizer = torch.optim.Adam(
        model_conv.parameters(), lr=args.lr, weight_decay=args.weight_decay_conv)#Adam优化器

    scheduler = torch.optim.lr_scheduler.StepLR(
        optimizer, step_size=25, gamma=0.5, last_epoch=-1)

    margin_loss = torch.nn.SoftMarginLoss()

    epoch_losses = []   # losses of all epochs
    print("Number of epochs {}".format(args.epochs_conv))

    for epoch in range(args.epochs_conv):#训练解码器
        print("\nepoch-> ", epoch)
        random.shuffle(Corpus_.train_triples)
        Corpus_.train_indices = np.array(
            list(Corpus_.train_triples)).astype(np.int32)

        model_conv.train()  # getting in training mode
        start_time = time.time()
        epoch_loss = []

        if len(Corpus_.train_indices) % args.batch_size_conv == 0:
            num_iters_per_epoch = len(
                Corpus_.train_indices) // args.batch_size_conv
        else:
            num_iters_per_epoch = (
                len(Corpus_.train_indices) // args.batch_size_conv) + 1

        for iters in range(num_iters_per_epoch):
            start_time_iter = time.time()
            train_indices, train_values = Corpus_.get_iteration_batch(iters)

            if CUDA:
                train_indices = Variable(
                    torch.LongTensor(train_indices)).cuda()
                train_values = Variable(torch.FloatTensor(train_values)).cuda()

            else:
                train_indices = Variable(torch.LongTensor(train_indices))
                train_values = Variable(torch.FloatTensor(train_values))

            preds = model_conv(
                Corpus_, Corpus_.train_adj_matrix, train_indices)

            optimizer.zero_grad()

            loss = margin_loss(preds.view(-1), train_values.view(-1))

            loss.backward()
            optimizer.step()

            epoch_loss.append(loss.data.item())

            end_time_iter = time.time()

            print("Iteration-> {0}  , Iteration_time-> {1:.4f} , Iteration_loss {2:.4f}".format(
                iters, end_time_iter - start_time_iter, loss.data.item()))

        scheduler.step()
        print("Epoch {} , average loss {} , epoch_time {}".format(
            epoch, sum(epoch_loss) / len(epoch_loss), time.time() - start_time))
        epoch_losses.append(sum(epoch_loss) / len(epoch_loss))
        if epoch==(args.epochs_conv - 1):
            save_model(model_conv, args.data, epoch,args.output_folder + "convKB/")#保存解码模型，用于预测
    
    return epoch_losses

def evaluate_conv(args, unique_entities):
    model_conv = SpKBGATConvOnly(entity_embeddings, relation_embeddings, args.entity_out_dim, args.entity_out_dim,
                                 args.drop_GAT, args.drop_conv, args.alpha, args.alpha_conv,
                                 args.nheads_GAT, args.out_channels)
    model_conv.load_state_dict(torch.load(
        '{0}convKB/trained_{1}.pth'.format(args.output_folder, args.epochs_conv - 1)), strict=False)

    model_conv.cuda()
    model_conv.eval()
    with torch.no_grad():
        pred_tail_tripindex_txt,pred_tail_trip_txt=Corpus_.get_validation_pred(args, model_conv, unique_entities)
        #pred_tail_tripindex_txt,pred_tail_trip_txt可以保存弱点信息的补全结果
    
#train_gat(args)#将args的get_2hop设置为Ture，训练GAT提取正向邻域特征
#train_gat(args)#将args的get_2hop_re设置为Ture，训练GAT提取逆向邻域特征

conv_epoch_losses=train_conv(args)#这时get_2hop设置为Ture，get_2hop_re设置为False
conv_loss_pd = pd.DataFrame(conv_epoch_losses) #将训练Conv的过程的损失存储下来
conv_loss_pd.to_csv(args.output_folder+'Conv_epoch_loss.csv')


evaluate_conv(args, Corpus_.unique_entities_train)
